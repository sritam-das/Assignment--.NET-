﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_workshop_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Horroscope horrObj = new Horroscope();
            List<Horroscope> scope = new List<Horroscope>(); 
            string val = "ok";
            while (val=="ok")
            {
                Console.WriteLine("---------------Welcome To Horroscope------------------------");
                Console.WriteLine("Enter Your Name :");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Your Date Of Birth");
                Console.WriteLine("Enter Day :");
                int day = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Month :");
                int month = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter year :");
                int year = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Your Age :");
                int age = int.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Your Sun Sign is:");
                string sun_signs = horrObj.zodiac_sign(day,month);
                Console.WriteLine(sun_signs);
                string signType = horrObj.sign_type(sun_signs);
                Console.WriteLine(signType);
                scope.Add(new Horroscope { Name = name, Dob = new DateTime(year, month, day), Age = age, sign = sun_signs, type = signType  });
                Console.WriteLine("If you want to continue raise ok otherwise end");
                val =Console.ReadLine();    
              
            }
            Console.WriteLine();
            Console.WriteLine("Horroscope Customers :");
            Console.WriteLine();
            foreach(Horroscope element in scope)
            {
                Console.WriteLine("Name :"+element.Name+" DateOfBirth :"+element.Dob+" Age :"+element.Age
                    +" Sign :"+element.sign+" Type :"+element.type);
            }

            //------- Linq Query-------------------------
            Console.WriteLine("---------------------Question 1--------------------------");
            Console.WriteLine();
            var que1 = from objs in scope
                       where objs.type == "Water"
                       select objs;
            foreach(var horror in que1)
            {
                Console.WriteLine("Name :" + horror.Name
                    + " Sign :" + horror.sign + " Type :" + horror.type);
            }

            Console.WriteLine("---------------------Question 2--------------------------");
            Console.WriteLine();
            var que2 = from objs in scope
                       orderby objs.Dob ascending
                       select objs;
            foreach (Horroscope horror in que2)
            {
                Console.WriteLine("Name :" + horror.Name+" DateOOfBirth :"+ horror.Dob
                    + " Sign :" + horror.sign + " Type :" + horror.type);
            }

            Console.WriteLine("---------------------Question 3--------------------------");
            Console.WriteLine();
            var que3 = from objs in scope
                       orderby objs.sign ascending
                       select objs;
            foreach (Horroscope horror in que3)
            {
                Console.WriteLine("Name :" + horror.Name + " DateOOfBirth :" + horror.Dob
                    + " Sign :" + horror.sign + " Type :" + horror.type);
            }

            Console.WriteLine("---------------------Question 4--------------------------");
            Console.WriteLine();
            int userMax = int.Parse(scope.Max(user => user.sign));
            int userMin = int.Parse(scope.Min(user => user.sign));
            Console.WriteLine("Max user :"+ userMax +" Min User :"+ userMin);

            Console.WriteLine("---------------------Question 5--------------------------");
            Console.WriteLine();








        }
    }
}
