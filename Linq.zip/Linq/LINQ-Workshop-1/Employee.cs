﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Workshop_1
{
    class Employee
    {
        public int DeptID { get; set; }
        public string Name { get; set; }
        public DateTime Doj { get; set; }
        public double Salary { get; set; }
        public string Designation { get; set; }
    }
}
