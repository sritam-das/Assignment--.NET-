﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Workshop_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* DeptID Name Doj Sal Designation
10 Harshad 30-jun-2014 65000.00 System Analyst
12 Anagha 14-mar-2018 89500.00 Manager
5 Swizzle 20-jun-2019 78500.00 Team Lead
17 Brotin 6-jul-2012 65421.00 Testing Engineer
17 Pravin 10-aug-2010 78605.50 System Analyst
10 Anant 4-sep-2013 56000.00 Quality Analyst
5 Viraj 3-oct-2019 37500.50 Developer
3 Namrata 14-feb-2020 42500.50 System Analyst
17 Mitali 23-jan-2014 62500.50 Team Lead
10 Swayam 13-oct-2012 27500.50 Testing Engineer
2 Zeeshan 18-oct-2016 22500.50 Developer*/

            List<Employee> employees = new List<Employee>
            {
                new Employee{DeptID=10,Name="Harshad",Doj=new DateTime(2014,06,30),Salary=65000.00,Designation="System Analyst"},
                new Employee{DeptID=12,Name="Anagha",Doj=new DateTime(2018,03,14),Salary=89500.00,Designation="Manager"},
                new Employee{DeptID=5,Name="Swizzle",Doj=new DateTime(2019,06,20),Salary=78500.00,Designation="Team Lead"},
                new Employee{DeptID=17,Name="Brootin",Doj=new DateTime(2012,07,06),Salary=65421.00,Designation="Testing Engineer"},
                new Employee{DeptID=17,Name="Pravin",Doj=new DateTime(2010,08,10),Salary=78605.00,Designation="System Analyst"},
                new Employee{DeptID=10,Name="Anant",Doj=new DateTime(2013,09,04),Salary=56000.00,Designation="Quality Analyst"},
                new Employee{DeptID=5,Name="Viraj",Doj=new DateTime(2019,10,03),Salary=37500.50,Designation="Developer"},
                new Employee{DeptID=3,Name="Namrata",Doj=new DateTime(2020,02,14),Salary=42500.50,Designation="System Analyst"},
                new Employee{DeptID=17,Name="Mitali",Doj=new DateTime(2014,01,23),Salary=62500.50,Designation="Team Lead"},
                new Employee{DeptID=10,Name="Swayam",Doj=new DateTime(2012,10,13),Salary=27500.50,Designation="Testing Engineer"},
                new Employee{DeptID=2,Name="Zeeshan",Doj=new DateTime(2016,10,18),Salary=22500.50,Designation="Developer"},
            };
            foreach (Employee empObj in employees)
            {
                Console.WriteLine("DeptId: {0} \tName: {1} \tDoj: {2} \tSalary: {3} \tDesignation: {4}",
                    empObj.DeptID, empObj.Name, empObj.Doj, empObj.Salary, empObj.Designation);
            }
            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++Question 1+++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var empSalaryLessthan70000 = from empObj in employees
                                         where empObj.Salary < 70000
                                         select empObj;

            foreach (Employee empObj in empSalaryLessthan70000)
            {
                Console.WriteLine("DeptId: {0} \tName: {1} \tDoj: {2} \tSalary: {3} \tDesignation: {4}",
                    empObj.DeptID, empObj.Name, empObj.Doj, empObj.Salary, empObj.Designation);
            }

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++Question 2+++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var empDesignation = from empObj in employees
                                 where empObj.Designation == "Manager" || empObj.Designation == "Analyst"
                                 select empObj;

            foreach (Employee empObj in empDesignation)
            {
                Console.WriteLine("Name: {0}  \tDesignation: {1}",
                    empObj.Name, empObj.Designation);
            }

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++Question 3+++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var que3 = from empObj in employees
                       where empObj.DeptID == 10 && empObj.Salary > 20000
                       select empObj;

            foreach (Employee empObj in que3)
            {
                Console.WriteLine("Name: {0}  \tDesignation: {1} \tSalary: {2}",
                    empObj.Name, empObj.Designation, empObj.Salary);
            }

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++Question 4+++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var que4 = from empObj in employees
                       where empObj.Name.StartsWith("V")
                       select empObj;

            foreach (Employee empObj in que4)
            {
                Console.WriteLine("Name: {0}  \tDesignation: {1} \tSalary: {2}",
                    empObj.Name, empObj.Designation, empObj.Salary);
            }

            Console.WriteLine();
            Console.WriteLine("++++++++++++++++++++++++++++Question 5++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var que5 = from empObj in employees
                       where empObj.Name.Contains("oo")
                       select empObj;


            foreach (var empObj in que5)
            {
                Console.WriteLine("Name: {0}  \tDesignation: {1} \tSalary: {2}",
                    empObj.Name, empObj.Designation, empObj.Salary);
            }

            Console.WriteLine();
            Console.WriteLine("++++++++++++++++++++++++++++Question 6++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var que6 = from Employee empObj in employees
                       where empObj.Salary < 60000
                       select new { Salary = empObj.Salary + 1000 };

            foreach (var empObj in que6)
            {
                Console.WriteLine("New Salary for Employees:",
                empObj.Salary.ToString());
            }

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++++Question 7+++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();

            var que7 = from empObj in employees
                       group empObj by empObj.DeptID into EmpGroup
                       select new
                       {
                           DeptId = EmpGroup.Key,
                           AverageSalary = EmpGroup.Average(x => x.Salary),
                       };

                foreach (var e in que7)
                {
                    Console.WriteLine(e);
                }

            Console.WriteLine();
            Console.WriteLine("++++++++++++++++++++++++++++++Question 8++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Record of two employees drawing highest salaries:");
            Console.WriteLine();
            var record2epmloyeeshighestSalaries = from empObj in employees
                                                  orderby empObj.Salary descending
                                                  select empObj;
            foreach(Employee empObj in record2epmloyeeshighestSalaries.Take(2))
            {
                Console.WriteLine("Name: {0} \tSalary: {1}",
                    empObj.Name, empObj.Salary);
            }

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++++++Question 9+++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Record of Sum, Max, Min Salaries:");
            Console.WriteLine();

            double maxSalary = employees.Max(employee => employee.Salary);
            double minSalary = employees.Min(employee => employee.Salary);
            double avgSalary = employees.Average(employee => employee.Salary);
            double sumSalary = employees.Sum(employee => employee.Salary);

            Console.WriteLine("Max Salary --"+maxSalary+" Min Salary --"+minSalary+" Average Salary --"+avgSalary+
                "  Sum Salary --"+sumSalary);

            Console.WriteLine();
            Console.WriteLine("+++++++++++++++++++++++++++++++Question 10+++++++++++++++++++++++++++++++++++");

            // 10.Create groups of salary like 10000 to 20000, 21000 to 30000...and display the min and max salary in each group

            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine("Create groups of salary like 10000 to 20000, 21000 to 30000. Min and Max salary in each group: ");
            Console.WriteLine();
            int[] ranges = new int[9] { 0, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000 };
            for (int i = 1; i < ranges.Length - 1; i++)
            {
                var MinandMaxSalInEachGroup = (from Employee emp in employees
                                               where emp.Salary > ranges[i - 1] && emp.Salary < ranges[i]
                                               select emp);
                /* 
                 foreach(Employee emp in MinandMaxSalInEachGroup)
                 {
                     Console.WriteLine(employees);
                 }
                 */
                if (MinandMaxSalInEachGroup.Count() != 0)
                {
                    Console.WriteLine("-------------------------------------------------------------");
                    var minSal = MinandMaxSalInEachGroup.Min(employee => employee.Salary);
                    var maxSal = MinandMaxSalInEachGroup.Max(employee => employee.Salary);
                    Console.WriteLine("Min and Max Salary between range: " + ranges[i - 1] + " to "
                        + ranges[i] + "   is " + minSal + " and " + maxSal + " respectively ");

                }

            }




        }
    }
}
