﻿using System.Collections.Generic;

namespace WEBAPI_Workshop.DTO
{
    public class MovieDTO
    {
        public string MovieTitle { get; set; }
        public int MovieYear { get; set; }
        public List<string> GenresTitle { get; set; } = new List<string>();
        public List<string> DirectorNames { get; set; } = new List<string>();
    }
}
