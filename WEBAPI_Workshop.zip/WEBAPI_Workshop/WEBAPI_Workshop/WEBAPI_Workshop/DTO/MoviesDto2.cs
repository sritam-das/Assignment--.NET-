﻿using System;
using System.Collections.Generic;

namespace WEBAPI_Workshop.DTO
{
    /*
     * List all the movies with title, year, date of release, movie duration, and first 
and last name of the director
     */
    public class MoviesDto2
    {
        public string Title { get; set; }
        public int Year { get; set; }
        public DateTime DateOfRelease { get; set; }
        public int Duration { get; set; }
        public List<string> DirectorsFirstName { get; set; }
        public List<string> DirectorsLastName { get; set; }
    }
}
