﻿using System.Collections.Generic;

namespace WEBAPI_Workshop.DTO
{
    //along with the year, director's name, 
    //actor's name
    public class MoviesWithYearDirectorsNameActorsNameDTO
    {
        public int Year { get; set; }
        public List<string> DirectorsName { get; set; }
        public List<string> ActorsName { get; set; }
    }
}
