﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ASP_WEB_API_Workshop.Models
{
    public class MovieCast
    {
        [ForeignKey("Actor")]
        public int ActorId { get; set; }
        [ForeignKey("Movie")]
        public int MovieId { get; set; }
        [StringLength(30)]
        public string Role { get; set; }
    }
}
