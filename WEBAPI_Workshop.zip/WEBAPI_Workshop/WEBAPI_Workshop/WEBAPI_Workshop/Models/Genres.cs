﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASP_WEB_API_Workshop.Models
{
    public class Genres
    {
        [Key]
        public int GenreId { get; set; }
        [StringLength(20)]
        public string GenreTitle { get; set; }
        public List<Movie> Movies { get; set; } = new List<Movie>();
    }
}
