﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASP_WEB_API_Workshop.Models
{
    public class Actor
    {
        [Key]
        public int ActorId { get; set; }
        [StringLength(20)]
        public string ActorFirstName { get; set; }
        [StringLength(20)]
        public string ActorLastName { get; set; }
        public char Gender { get; set; }
        public List<Movie> Movies { get; set; } = new List<Movie>();
    }
}
