﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASP_WEB_API_Workshop.Models
{
    public class Director
    {
        [Key]
        public int DirectorId { get; set; }
        [StringLength(20)]
        public string DirectorFirstName { get; set; }
        [StringLength(20)]
        public string DirectorLastName { get; set; }
        public List<Movie> Movies { get; set; } = new List<Movie>();
    }
}
