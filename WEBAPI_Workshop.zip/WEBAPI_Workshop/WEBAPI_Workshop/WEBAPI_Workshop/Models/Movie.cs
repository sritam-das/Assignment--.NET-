﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASP_WEB_API_Workshop.Models
{
    public class Movie
    {
        [Key]
        public int Movie_Id { get; set; }
        [StringLength(50)]
        public string MovieTitle { get; set; }
        public int MovieYear { get; set; }
        public int MovieTime { get; set; }
        [StringLength(50)]
        public string MovieLanguage { get; set; }
        public DateTime MovieReleaseDate { get; set; }
        [StringLength(5)]
        public string MovieRelContry { get; set; }
        public List<Director> Directors { get; set; } = new List<Director>();
        public List<Actor> Actors { get; set; } = new List<Actor>();
        public List<Genres> Genres { get; set; } = new List<Genres>();
        public List<Rating> Ratings { get; set; } = new List<Rating>();
    }
}
