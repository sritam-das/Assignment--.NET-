﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ASP_WEB_API_Workshop.Models
{
    public class Rating
    {
        [Key]
        public int RatingId { get; set; }
        [ForeignKey("Reviewer")]
        public int ReviewerId { get; set; }
        public int Stars { get; set; }
        public int NumberOfRatings { get; set; }
    }
}
