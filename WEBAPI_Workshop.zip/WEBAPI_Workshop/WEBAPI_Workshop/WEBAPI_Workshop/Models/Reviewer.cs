﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ASP_WEB_API_Workshop.Models
{
    public class Reviewer
    {
        [Key]
        public int ReviewerId { get; set; }
        [StringLength(30)]
        public string ReviewerName { get; set; }
        public List<Rating> Ratings { get; set; } = new List<Rating>();
    }
}
