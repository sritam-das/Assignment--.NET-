﻿using Microsoft.AspNetCore.Mvc;
using WEBAPI_Workshop.Models;

namespace WEBAPI_Workshop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorController : ControllerBase
    {
        IActorService _actorService;

        public ActorController(IActorService actorService)
        {
            _actorService = actorService;
        }

        [HttpGet]
        [Route("actors")]
        public IActionResult GetActorsWhoDidNotWorkBetween1990And2000()
        {
            var actors = _actorService.GetActorsWhoHaveNotWorkedBetween1990And2000();
            if (actors == null)
            {
                return NoContent();
            }
            return Ok(actors);
        }

        [HttpGet]
        [Route("actorsWhoWereDirectedAndActed")]
        public IActionResult GetActorsWhoDirectedAndActedInSameMovie()
        {
            var actors = _actorService.ActorsWhoAlsoDirectedAndActedInSameMovie();
            if (actors == null)
            {
                return NoContent();
            }
            return Ok(actors);
        }
    }
}
