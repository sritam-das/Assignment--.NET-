﻿using Microsoft.AspNetCore.Mvc;
using WEBAPI_Workshop.Models;

namespace WEBAPI_Workshop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        IMovieService _movieService;

        public MovieController(IMovieService movieService)
        {
            _movieService = movieService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var movies = _movieService.GetAllMovies();
            if (movies == null)
            {
                return NoContent();
            }
            return Ok(movies);
        }

        [HttpGet]
        [Route("MoviesBefore1989")]
        public IActionResult GetAllMoviesBefore1989()
        {
            var movies = _movieService.GetAllMoviesBefore1989();
            if (movies == null)
            {
                return NoContent();
            }
            return Ok(movies);
        }

        [HttpGet]
        [Route("LowestDurationMovie")]
        public IActionResult GetMovieWithLowestDuration()
        {
            var movies = _movieService.GetLowestDurationMovie();
            if (movies == null)
            {
                return NoContent();
            }
            return Ok(movies);
        }

        [HttpGet]
        [Route("YearsThatProducedLowRatedMovies")]
        public IActionResult GetAllYearsThatProducedLowRatedMovies()
        {
            var years = _movieService.GetAllYearsWhichProducedMoviesOfRating3Or4();
            if (years == null)
            {
                return NoContent();
            }
            return Ok(years);
        }
    }
}
