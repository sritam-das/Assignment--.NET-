﻿using System.Collections.Generic;
using WEBAPI_Workshop.DTO;

namespace WEBAPI_Workshop.Models
{
    public interface IMovieService
    {
        public List<MovieDTO> GetAllMovies();
        public List<MoviesDto2> GetAllMoviesBefore1989();
        public MoviesWithYearDirectorsNameActorsNameDTO GetLowestDurationMovie();
        public List<int> GetAllYearsWhichProducedMoviesOfRating3Or4();
    }
}
