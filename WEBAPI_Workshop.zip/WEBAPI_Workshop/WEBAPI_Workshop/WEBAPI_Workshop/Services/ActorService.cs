﻿using ASP_WEB_API_Workshop.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using WEBAPI_Workshop.DTO;

namespace WEBAPI_Workshop.Models
{
    public class ActorService : IActorService
    {
        ApplicationDbContext _applicationDb;

        public ActorService(ApplicationDbContext applicationDb)
        {
            _applicationDb = applicationDb;
        }

        public List<Actor> GetActorsWhoHaveNotWorkedBetween1990And2000()
        {
            List<Movie> moviesMadeBetween1990And2000 = _applicationDb.Movies.Where(m =>
            m.MovieYear >= 1990 || m.MovieYear <= 2000).ToList();
            List<int> movies = new List<int>();
            foreach (var movie in moviesMadeBetween1990And2000)
            {
                movies.Add(movie.Movie_Id);
            }
            var moviesCast = _applicationDb.MovieCast.Where(mc =>
            movies.Contains(mc.MovieId));
            List<int> actors = new List<int>();
            foreach (var cast in moviesCast.Distinct())
            {
                actors.Add(cast.ActorId);
            }
            return _applicationDb.Actors.Where(a => !actors.Contains(a.ActorId)).ToList();
        }

        public List<ActorWithFirstAndLastNameAndRoleDTO> ActorsWhoAlsoDirectedAndActedInSameMovie()
        {
            var movies = _applicationDb.Movies.ToList();
            foreach (var movie in movies)
            {
                _applicationDb.Entry(movie).Collection(m => m.Directors).Load();
                _applicationDb.Entry(movie).Collection(m => m.Actors).Load();
                //_applicationDb.MovieCast
            }
            List<ActorWithFirstAndLastNameAndRoleDTO> actors = new List<ActorWithFirstAndLastNameAndRoleDTO>();
            foreach (var movie in movies)
            {
                foreach (var director in movie.Directors)
                {
                    foreach (var actor in movie.Actors)
                    {
                        if (actor.ActorFirstName.Equals(director.DirectorFirstName) &&
                            actor.ActorLastName.Equals(director.DirectorLastName))
                        {

                            actors.Add(
                            new ActorWithFirstAndLastNameAndRoleDTO
                            {
                                FirstName = actor.ActorFirstName,
                                LastName = actor.ActorLastName,
                                Role = _applicationDb.MovieCast.SingleOrDefault(mc =>
                                mc.ActorId == actor.ActorId && mc.MovieId == movie.Movie_Id).Role
                            }
                            );
                        }
                    }
                }
            }
            return actors;
        }
    }
}
