﻿using ASP_WEB_API_Workshop.Models;
using System.Collections.Generic;
using WEBAPI_Workshop.DTO;

namespace WEBAPI_Workshop.Models
{
    public interface IActorService
    {
        public List<Actor> GetActorsWhoHaveNotWorkedBetween1990And2000();
        public List<ActorWithFirstAndLastNameAndRoleDTO> ActorsWhoAlsoDirectedAndActedInSameMovie();
    }
}
