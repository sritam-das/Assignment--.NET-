﻿using ASP_WEB_API_Workshop.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using WEBAPI_Workshop.DTO;

namespace WEBAPI_Workshop.Models
{
    public class MovieService : IMovieService
    {
        ApplicationDbContext _applicationDb;

        public MovieService(ApplicationDbContext applicationDb)
        {
            _applicationDb = applicationDb;
        }

        public List<MovieDTO> GetAllMovies()
        {
            List<Movie> movies = _applicationDb.Movies.ToList();
            foreach (Movie movie in movies)
            {
                _applicationDb.Entry(movie).Collection(m => m.Directors).Load();
                _applicationDb.Entry(movie).Collection(m => m.Genres).Load();
            }

            List<MovieDTO> moviesDto = new List<MovieDTO>();
            foreach (Movie movie in movies)
            {
                List<string> genreTitles = new List<string>();
                foreach (var genre in movie.Genres)
                {
                    genreTitles.Add(genre.GenreTitle);
                }

                List<string> directorName = new List<string>();
                foreach (var director in movie.Directors)
                {
                    directorName.Add(director.DirectorFirstName);
                }

                moviesDto.Add(
                    new MovieDTO
                    {
                        MovieTitle = movie.MovieTitle,
                        MovieYear = movie.MovieYear,
                        GenresTitle = genreTitles,
                        DirectorNames = directorName
                    }
               );
            }
            return moviesDto;
        }

        public List<MoviesDto2> GetAllMoviesBefore1989()
        {
            List<MoviesDto2> moviesDto = new List<MoviesDto2>();
            var movies = _applicationDb.Movies.Where(m =>
             m.MovieReleaseDate < new DateTime(1989, 01, 01)).ToList();
            foreach (Movie movie in movies)
            {
                _applicationDb.Entry(movie).Collection(m => m.Directors).Load();
            }
            foreach (var movie in movies)
            {
                List<string> directorFirstName = new List<string>();
                foreach (var director in movie.Directors)
                {
                    directorFirstName.Add(director.DirectorFirstName);
                }

                List<string> directorLastName = new List<string>();
                foreach (var director in movie.Directors)
                {
                    directorLastName.Add(director.DirectorLastName);
                }

                moviesDto.Add(
                    new MoviesDto2
                    {
                        Title = movie.MovieTitle,
                        Year = movie.MovieYear,
                        Duration = movie.MovieTime,
                        DateOfRelease = movie.MovieReleaseDate,
                        DirectorsFirstName = directorFirstName,
                        DirectorsLastName = directorLastName
                    }
                );
            }
            return moviesDto;
        }

        public MoviesWithYearDirectorsNameActorsNameDTO GetLowestDurationMovie()
        {
            Movie movie = _applicationDb.Movies.OrderBy(m => m.MovieTime).LastOrDefault();
            _applicationDb.Entry(movie).Collection(m => m.Directors).Load();
            List<string> directors = new List<string>();
            foreach (var director in movie.Directors)
            {
                directors.Add(director.DirectorFirstName);
            }
            //_applicationDb.Entry(movie).Collection(m => m.Actors).Load();
            List<string> actors = new List<string>();
            foreach (var actor in movie.Actors)
            {
                actors.Add(actor.ActorFirstName);
            }
            return new MoviesWithYearDirectorsNameActorsNameDTO
            {

                Year = movie.MovieYear,
                ActorsName = actors,
                DirectorsName = directors

            };
        }

        public List<int> GetAllYearsWhichProducedMoviesOfRating3Or4()
        {
            List<int> years = new List<int>();
            var movies = _applicationDb.Movies.Include(m => m.Ratings).ToList();
            foreach (var movie in movies)
            {
                foreach (var rating in movie.Ratings)
                {
                    if (rating.Stars == 3 || rating.Stars == 4)
                    {
                        years.Add(movie.MovieYear);
                    }
                }
            }
            return years.Distinct().ToList();
        }
    }
}
